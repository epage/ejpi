import os

__pretty_app_name__ = "e**(j pi) + 1 = 0"
__app_name__ = "ejpi"
__version__ = "0.9.7"
__build__ = 1
_data_path_ = os.path.join(os.path.expanduser("~"), ".ejpi")
__app_magic__ = 0xdeadbeef
_user_logpath_ = "%s/ejpi.log" % _data_path_
